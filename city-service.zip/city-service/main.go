package main

import (
  fmt "fmt"
  http "net/http"

  consul "city-service/consul"
)

func main() {

  client, err := consul.NewConsulClient("http://localhost:8500")
  if(err != nil) {
    panic(err)
  }
  err = client.Register("city-service", 8082)
  if(err != nil) {
    panic(err)
  }
  http.ListenAndServe(":8082", NewRouter())
}

func homeHandler(writer http.ResponseWriter, request *http.Request) {
  fmt.Fprintf(writer, "<h1>%s</h1>", "Hi, Service is UP and Running!")
}
