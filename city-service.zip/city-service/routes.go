package main

import (
  //mux "github.com/gorilla/mux"
  http "net/http"
  cityHandler "city-service/controllers"
)

type Route struct {
  Name string
  Method string
  Pattern string
  HandlerFunc http.HandlerFunc
}

type Routes []Route

var routes = Routes{
  Route{
    "Home",
    "GET",
    "/",
    homeHandler,
  },
  Route{
    "Save-City",
    "POST",
    "/city",
    cityHandler.Save,
  },
  Route{
    "Find-City",
    "GET",
    "/city/{code}",
    cityHandler.FindOne,
  },
}
