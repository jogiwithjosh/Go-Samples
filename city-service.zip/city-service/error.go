package main

type JsonError struct {
  Code string
  Message string
}
